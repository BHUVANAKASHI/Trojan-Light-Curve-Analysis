let angle=0;
let model_1;
function setup() {
  createCanvas(windowWidth, windowHeight, WEBGL);
}
function preload(){
  model_1=loadImage('texture.png');
 
}

function draw(){
  background(0);
 //ambientLight(100);
  directionalLight(255,25,0,mouseX,mouseY,0);
  //rotateX(angle);
  //translate(0, 0, 0);
  push();
  rotateZ(frameCount * 0.01);
  rotateX(frameCount * 0.01);
  rotateY(frameCount * 0.01);
  
     //fill(200,0,255);
  //noStroke();

  sphere(100,200,2);
      pop();

    
   
      ambientLight(100);
  rotateX(angle);
  //translate(200, 0, 0);
  push();
  rotateZ(frameCount * 0.01);
  rotateX(frameCount * 0.01);
  rotateY(frameCount * 0.01);
 // fill(200,0,255);
  //stroke(0);
  texture(model_1);
  sphere(100,200,2);
  
  pop();
        
  
 // angle +=0.01;
  

  
  
}