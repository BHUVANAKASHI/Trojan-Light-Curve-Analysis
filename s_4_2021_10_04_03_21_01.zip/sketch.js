let angle=0;
let model_1;
function setup() {
  createCanvas(windowWidth, windowHeight, WEBGL);
}
function preload(){
  model_1=loadImage('texture.png');
 
}

function draw(){
  dx= mouseX-width/2;
  dy=mouseY-height/2;
  directionalLight(255,225,0,dx,dy,1);
    background(170);

  //rotateX(angle);
  //translate(0, 0, 0);
  push();
  rotateZ(angle * 1.3);
  rotateX(angle);
  rotateY(angle * 0.2);
  
     //fill(200,0,255);
  noStroke();
ambientMaterial(255);
  torus(10,100,8);
      pop();

    
   
        
  
 angle +=0.03;
  

  
  
}